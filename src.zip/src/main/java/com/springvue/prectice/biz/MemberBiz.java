package com.springvue.prectice.biz;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springvue.prectice.dto.MemberDto;

@Service
public interface MemberBiz {
	public List<MemberDto>selectList();
	public int insertmember(MemberDto dto);
	public int deletemember(int no);
	public MemberDto selectOne(int no);
	public int updatemember(MemberDto dto);
}
