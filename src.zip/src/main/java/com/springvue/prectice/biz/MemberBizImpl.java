package com.springvue.prectice.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springvue.prectice.dto.MemberDto;
import com.springvue.prectice.mapper.MemberMapper;

@Service
public class MemberBizImpl implements MemberBiz{

	@Autowired
	private MemberMapper membermapper;
	
	@Override
	public List<MemberDto> selectList() {
		// TODO Auto-generated method stub
		return membermapper.selectList();
	}

	@Override
	public int insertmember(MemberDto dto) {
		// TODO Auto-generated method stub
		return membermapper.insertmember(dto);
	}

	@Override
	public int deletemember(int no) {
		// TODO Auto-generated method stub
		return membermapper.deletemember(no);
	}

	@Override
	public MemberDto selectOne(int no) {
		// TODO Auto-generated method stub
		return membermapper.selectOne(no);
	}

	@Override
	public int updatemember(MemberDto dto) {
		// TODO Auto-generated method stub
		return membermapper.updatemember(dto);
	}

}
