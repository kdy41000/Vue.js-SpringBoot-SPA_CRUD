package com.springvue.prectice.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.springvue.prectice.dto.MemberDto;

@Mapper
public interface MemberMapper {
	
	@Select(" SELECT * FROM VUEMEMBER ORDER BY NO DESC ")
	List<MemberDto> selectList();
	
	@Insert(" INSERT INTO VUEMEMBER VALUES(VUEMEMBERSEQ.NEXTVAL,#{name},#{title},SYSDATE) ")
	public int insertmember(MemberDto dto);
	
	@Delete(" DELETE FROM VUEMEMBER WHERE NO = #{no} ")
	public int deletemember(int no);
	
	@Select(" SELECT * FROM VUEMEMBER WHERE NO = #{no} ")
	public MemberDto selectOne(int no);
	
	@Update(" UPDATE VUEMEMBER SET NAME = #{name}, TITLE = #{title} WHERE NO = #{no} ")
	public int updatemember(MemberDto dto);
}
