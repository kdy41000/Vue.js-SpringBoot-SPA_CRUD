package com.springvue.prectice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.springvue.prectice.biz.MemberBiz;
import com.springvue.prectice.dto.MemberDto;

@Controller
public class TestController {

	@Autowired
	private MemberBiz memberbiz;
	
	@GetMapping("/list")
	public ResponseEntity<?> TestMethod() {
		System.out.println("전체조회 컨트롤러 호출");
		List<MemberDto> list = memberbiz.selectList();

		return ResponseEntity.ok(list);
	}
	
	@PostMapping("/insertmember")
	public ResponseEntity<Boolean> InsertMember(String name, String title) {
		System.out.println("멤버 등록 컨트롤러");
		boolean gubun = false;
		MemberDto dto = new MemberDto();
		dto.setName(name);
		dto.setTitle(title);
		int res = memberbiz.insertmember(dto);
		
		if(res > 0) {
			System.out.println("인서트 성공");
			gubun = true;
		}else {
			System.out.println("인서트 실패");
		}
		return ResponseEntity.ok(gubun);
	}
	
	@PostMapping("/delete")
	public ResponseEntity<Boolean> DeleteMember(int no){
		System.out.println("삭제 컨트롤러");
		boolean gubun = false;
		int res = memberbiz.deletemember(no);
		
		if(res > 0) {
			System.out.println("삭제 성공");
			gubun = true;
		}else {
			System.out.println("삭제 실패");
		}
		return ResponseEntity.ok(gubun);
	}
	
	@PostMapping("/updatebeforeselect")
	public ResponseEntity<?> UpdateBeforeSelect(int no) {
		System.out.println("업데이트 전 조회 컨트롤러");
		MemberDto dto = memberbiz.selectOne(no);
		
		return ResponseEntity.ok(dto);
	}
	
	@PostMapping("/updatemember")
	public ResponseEntity<Boolean> UpdateMember(MemberDto dto) {
		System.out.println("업데이트 컨트롤러");
		int res = memberbiz.updatemember(dto);
		boolean gubun = false;
		if(res > 0) {
			gubun = true;
		}
		return ResponseEntity.ok(gubun);
	}
	
}
