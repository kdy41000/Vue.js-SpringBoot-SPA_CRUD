package com.springvue.prectice.dto;

import java.util.Date;

public class MemberDto {

	private int no;
	private String name;
	private String title;
	private Date wrtdate;
	
	public MemberDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MemberDto(int no, String name, String title, Date wrtdate) {
		super();
		this.no = no;
		this.name = name;
		this.title = title;
		this.wrtdate = wrtdate;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getWrtdate() {
		return wrtdate;
	}

	public void setWrtdate(Date wrtdate) {
		this.wrtdate = wrtdate;
	}
	
	
}
